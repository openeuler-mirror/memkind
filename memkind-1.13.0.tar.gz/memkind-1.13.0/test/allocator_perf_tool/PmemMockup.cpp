// SPDX-License-Identifier: BSD-2-Clause
/* Copyright (C) 2018 - 2020 Intel Corporation. */
#include "PmemMockup.hpp"

struct memkind *MEMKIND_PMEM_MOCKUP;
